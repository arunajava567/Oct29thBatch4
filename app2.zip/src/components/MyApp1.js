import React,{Component} from 'react'
//stateless
class MyApp1 extends Component {
       render() {
        return (
            <div className="App">
      
             <h1> My First Class Component </h1>
            
            </div>
          );
    }
}

export default MyApp1;