
function MyApp() {
    return (
      <div className="App">


       <h1> My First Functional React Component </h1>
       <form >

<input type="text"/>
<inpt type="submit"/>

       </form>
      </div>
    );
  }
  //functional component
  export default MyApp;