import MyApp from './components/MyApp'
import MyApp1 from './components/MyApp1'

function App() {
  return (
    <div className="App">
     
      < h1> App Component -Parent, Container , root </h1>

      <MyApp/>
      <MyApp1/>

    </div>
  );
}

export default App;
