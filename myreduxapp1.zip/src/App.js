import Component1 from './Component1'

function App() {
  return (
    <div className="App">
     <Component1/>
    </div>
  );
}

export default App;
