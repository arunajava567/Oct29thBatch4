import React from 'react';
import store,{increment,decrement}   from './store';
class Component1 extends React.Component{
    state={
msg:'hello'
    }
    increment(){
store.dispatch(increment());
this.setState({'msg':store.getState()});
    }
    decrement(){
store.dispatch(decrement());
this.setState({'msg':store.getState()});
    }
    render(){
        return <div>
<h2>Component 1</h2>
            {this.state.msg}    <hr/>
<button onClick={()=>this.increment()}>Increment</button>  |
<button onClick={()=>this.decrement()}>Decrement</button>
</div>
    }
}
export default Component1;
