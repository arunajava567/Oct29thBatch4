import React from'react';
import {store} from'./sessionStore';
class DashboardComponent extends React.Component{
    state={uname:''};
    componentDidMount(){
        this.setState({uname:store.getState()})
    }
    render(){
        return<div>
            <h2>Dashboard Component</h2>
            Uname: {this.state.uname}
        </div>
    }
}
export default DashboardComponent;
