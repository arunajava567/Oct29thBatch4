import React from'react';

function DummyComponent() {
  return (
    <div className="container">
      <h1>Dummy Component</h1>      
    </div>
  );
}
 
export default DummyComponent;
