import React from'react';

import'./App.css';
import LoginComponent from'./LoginComponent';
 
function App() {
  return (
    <div className="container">
      <h1>Root Component</h1>      
    <LoginComponent/>
    </div>
  );
}
 
export default App;
